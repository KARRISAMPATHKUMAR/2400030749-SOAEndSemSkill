# Eureka Discovery Server

Service registry for the Banking Microservices architecture (`banking-jwt-api` and `api-gateway`).

## Run
1. Start this service **first** on port `8761`:
   ```bash
   mvn clean spring-boot:run
   ```
2. Open the Eureka Dashboard at `http://localhost:8761`.
