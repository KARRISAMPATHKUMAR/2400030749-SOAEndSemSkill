# Spring Cloud API Gateway

API Gateway routing incoming `/api/**` requests to `banking-jwt-api` via Netflix Eureka service discovery.

## Port Allocation
- **Eureka Server**: `8761`
- **Banking JWT API**: `8080`
- **API Gateway**: `8081`

## Test Endpoints via Gateway (`http://localhost:8081`)
- `POST http://localhost:8081/api/auth/register`
- `POST http://localhost:8081/api/auth/login`
- `GET http://localhost:8081/api/account/balance` (Header: `Authorization: Bearer <accessToken>`)
- `POST http://localhost:8081/api/transfers` (Header: `Authorization: Bearer <accessToken>`)
- `GET http://localhost:8081/api/transactions` (Header: `Authorization: Bearer <accessToken>`)
