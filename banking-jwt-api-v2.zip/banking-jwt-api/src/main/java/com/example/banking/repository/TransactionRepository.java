package com.example.banking.repository;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import com.example.banking.entity.BankTransaction;

public interface TransactionRepository extends JpaRepository<BankTransaction, Long> {
    List<BankTransaction> findByFromEmailOrToEmailOrderByCreatedAtDesc(String fromEmail, String toEmail);
}
