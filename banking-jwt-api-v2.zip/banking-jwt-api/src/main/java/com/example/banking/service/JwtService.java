package com.example.banking.service;

import java.util.Date;
import javax.crypto.SecretKey;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Service;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.io.Decoders;
import io.jsonwebtoken.security.Keys;

@Service
public class JwtService {
    @Value("${app.jwt.secret}") private String secret;
    @Value("${app.jwt.expiration-ms}") private long expirationMs;

    private SecretKey signingKey() {
        return Keys.hmacShaKeyFor(Decoders.BASE64.decode(secret));
    }
    public String generateToken(UserDetails user) {
        long now = System.currentTimeMillis();
        return Jwts.builder().subject(user.getUsername())
            .issuedAt(new Date(now)).expiration(new Date(now + expirationMs))
            .signWith(signingKey()).compact();
    }
    public String extractUsername(String token) {
        return Jwts.parser().verifyWith(signingKey()).build()
            .parseSignedClaims(token).getPayload().getSubject();
    }
}
