package com.example.banking.controller;

import java.util.Map;
import java.util.Locale;
import org.springframework.http.HttpStatus;
import org.springframework.security.authentication.*;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;
import org.springframework.validation.annotation.Validated;
import jakarta.validation.Valid;
import com.example.banking.dto.*;
import com.example.banking.entity.Customer;
import com.example.banking.repository.CustomerRepository;
import com.example.banking.service.JwtService;

@RestController
@RequestMapping("/api/auth")
@Validated
public class AuthController {
    private final CustomerRepository customers;
    private final PasswordEncoder encoder;
    private final AuthenticationManager authenticationManager;
    private final JwtService jwtService;
    public AuthController(CustomerRepository customers, PasswordEncoder encoder,
        AuthenticationManager authenticationManager, JwtService jwtService) {
        this.customers = customers; this.encoder = encoder;
        this.authenticationManager = authenticationManager; this.jwtService = jwtService;
    }

    @PostMapping("/register")
    public Map<String, String> register(@Valid @RequestBody RegisterRequest request) {
        String email = request.email().trim().toLowerCase(Locale.ROOT);
        if (customers.existsByEmail(email))
            throw new ResponseStatusException(HttpStatus.CONFLICT, "Email already registered");
        customers.save(new Customer(request.name().trim(), email, encoder.encode(request.password())));
        return Map.of("message", "Registration successful");
    }

    @PostMapping("/login")
    public Map<String, String> login(@Valid @RequestBody LoginRequest request) {
        String email = request.email().trim().toLowerCase(Locale.ROOT);
        try {
            authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(email, request.password()));
        } catch (AuthenticationException ex) {
            throw new ResponseStatusException(HttpStatus.UNAUTHORIZED, "Invalid email or password");
        }
        Customer customer = customers.findByEmail(email)
            .orElseThrow(() -> new ResponseStatusException(HttpStatus.UNAUTHORIZED, "Invalid credentials"));
        return Map.of("message", "Login successful", "accessToken", jwtService.generateToken(customer),
            "tokenType", "Bearer", "expiresInSeconds", "900");
    }
}
