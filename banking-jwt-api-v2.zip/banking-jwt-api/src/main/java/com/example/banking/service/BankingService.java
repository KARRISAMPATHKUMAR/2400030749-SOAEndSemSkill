package com.example.banking.service;

import java.math.BigDecimal;
import java.util.*;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;
import com.example.banking.dto.TransferRequest;
import com.example.banking.entity.*;
import com.example.banking.repository.*;

@Service
public class BankingService {
    private final CustomerRepository customers;
    private final TransactionRepository transactions;
    public BankingService(CustomerRepository customers, TransactionRepository transactions) {
        this.customers = customers; this.transactions = transactions;
    }

    @Transactional(readOnly = true)
    public Map<String, Object> balance(String email) {
        Customer c = customers.findByEmail(email)
            .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Customer not found"));
        return Map.of("name", c.getName(), "email", c.getEmail(), "balance", c.getBalance());
    }

    @Transactional
    public Map<String, Object> transfer(String senderEmail, TransferRequest request) {
        String recipientEmail = request.recipientEmail().trim().toLowerCase(Locale.ROOT);
        if (senderEmail.equalsIgnoreCase(recipientEmail))
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Cannot transfer to yourself");
        BigDecimal amount = request.amount();
        if (amount == null || amount.scale() > 2 || amount.compareTo(BigDecimal.ZERO) <= 0)
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Amount must be positive with at most 2 decimal places");

        List<Customer> locked = customers.lockCustomersByEmails(List.of(senderEmail, recipientEmail));
        Map<String, Customer> byEmail = new HashMap<>();
        locked.forEach(c -> byEmail.put(c.getEmail().toLowerCase(Locale.ROOT), c));
        Customer sender = byEmail.get(senderEmail.toLowerCase(Locale.ROOT));
        Customer recipient = byEmail.get(recipientEmail);
        if (sender == null) throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Sender account not found");
        if (recipient == null) throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Recipient account not found");
        if (sender.getBalance().compareTo(amount) < 0)
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Insufficient balance");

        sender.setBalance(sender.getBalance().subtract(amount));
        recipient.setBalance(recipient.getBalance().add(amount));
        customers.save(sender);
        customers.save(recipient);
        BankTransaction tx = transactions.save(new BankTransaction("TRANSFER", amount, senderEmail, recipientEmail));
        return Map.of("message", "Transfer successful", "transactionId", tx.getId(),
            "amount", amount, "from", senderEmail, "to", recipientEmail,
            "remainingBalance", sender.getBalance());
    }

    @Transactional(readOnly = true)
    public List<Map<String, Object>> history(String email) {
        return transactions.findByFromEmailOrToEmailOrderByCreatedAtDesc(email, email).stream()
            .map(t -> Map.<String, Object>of("transactionId", t.getId(), "type", t.getType(),
                "amount", t.getAmount(), "from", t.getFromEmail(), "to", t.getToEmail(),
                "createdAt", t.getCreatedAt()))
            .toList();
    }
}
