package com.example.banking.controller;

import java.util.List;
import java.util.Map;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;
import jakarta.validation.Valid;
import com.example.banking.dto.TransferRequest;
import com.example.banking.entity.Customer;
import com.example.banking.service.BankingService;

@RestController
@RequestMapping("/api")
public class TransferController {
    private final BankingService bankingService;
    public TransferController(BankingService bankingService) { this.bankingService = bankingService; }

    @PostMapping("/transfers")
    public Map<String, Object> transfer(@AuthenticationPrincipal Customer customer,
                                        @Valid @RequestBody TransferRequest request) {
        return bankingService.transfer(customer.getEmail(), request);
    }

    @GetMapping("/transactions")
    public List<Map<String, Object>> history(@AuthenticationPrincipal Customer customer) {
        return bankingService.history(customer.getEmail());
    }
}
