package com.example.banking.dto;

import java.math.BigDecimal;
import jakarta.validation.constraints.*;

public record TransferRequest(
    @NotBlank @Email String recipientEmail,
    @NotNull @DecimalMin(value = "0.01") @Digits(integer = 17, fraction = 2) BigDecimal amount
) {}
