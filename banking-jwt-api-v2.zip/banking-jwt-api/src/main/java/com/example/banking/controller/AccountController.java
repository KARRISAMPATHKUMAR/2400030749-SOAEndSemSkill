package com.example.banking.controller;

import java.util.Map;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;
import com.example.banking.entity.Customer;
import com.example.banking.service.BankingService;

@RestController
@RequestMapping("/api/account")
public class AccountController {
    private final BankingService bankingService;
    public AccountController(BankingService bankingService) { this.bankingService = bankingService; }

    @GetMapping("/balance")
    public Map<String, Object> balance(@AuthenticationPrincipal Customer customer) {
        return bankingService.balance(customer.getEmail());
    }
}
