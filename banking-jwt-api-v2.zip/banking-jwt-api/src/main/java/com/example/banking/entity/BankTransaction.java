package com.example.banking.entity;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import jakarta.persistence.*;

@Entity
@Table(name = "bank_transactions")
public class BankTransaction {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(nullable = false, length = 20)
    private String type;
    @Column(nullable = false, precision = 19, scale = 2)
    private BigDecimal amount;
    @Column(nullable = false, length = 190)
    private String fromEmail;
    @Column(nullable = false, length = 190)
    private String toEmail;
    @Column(nullable = false)
    private LocalDateTime createdAt;

    protected BankTransaction() {}
    public BankTransaction(String type, BigDecimal amount, String fromEmail, String toEmail) {
        this.type = type; this.amount = amount; this.fromEmail = fromEmail;
        this.toEmail = toEmail; this.createdAt = LocalDateTime.now();
    }
    public Long getId() { return id; }
    public String getType() { return type; }
    public BigDecimal getAmount() { return amount; }
    public String getFromEmail() { return fromEmail; }
    public String getToEmail() { return toEmail; }
    public LocalDateTime getCreatedAt() { return createdAt; }
}
