# Banking JWT API (Spring Boot + MySQL)

A learning/demo REST API demonstrating customer registration, login, JWT bearer-token authentication, balance lookup, money transfer, and transaction history.

> Not suitable for real banking or production use. It has no MFA, fraud detection, KYC, payment rails, refresh-token flow, idempotency keys, or production key management.

## Requirements
- Java 17+
- Maven 3.9+
- MySQL 8+
- Postman (optional)

## 1. Create database
```sql
CREATE DATABASE banking_db;
```

## 2. Configure database
Edit `src/main/resources/application.properties`, or set environment variables:
- `DB_URL` (default `jdbc:mysql://localhost:3306/banking_db?createDatabaseIfNotExist=true`)
- `DB_USERNAME` (default `root`)
- `DB_PASSWORD` (default `root`)
- `JWT_SECRET` (Base64-encoded random secret of at least 32 bytes)
- `JWT_EXPIRATION_MS` (default 900000 = 15 minutes)

The included JWT secret is for local learning only. Generate a new one for your environment. Never commit production secrets.

## 3. Run
From the project folder:
```bash
mvn clean spring-boot:run
```
Or import as **Existing Maven Project** in Eclipse and run `BankingApplication.java` as **Spring Boot App**.

## 4. Test in Postman

### Register customer A
`POST http://localhost:8080/api/auth/register`
```json
{"name":"Sampath","email":"sampath@example.com","password":"Test@123"}
```

### Register customer B
`POST http://localhost:8080/api/auth/register`
```json
{"name":"Ravi","email":"ravi@example.com","password":"Test@123"}
```

### Login
`POST http://localhost:8080/api/auth/login`
```json
{"email":"sampath@example.com","password":"Test@123"}
```
Copy `accessToken` from the response.

### Check balance
`GET http://localhost:8080/api/account/balance`
Header: `Authorization: Bearer <accessToken>`

### Transfer money
`POST http://localhost:8080/api/transfers`
Header: `Authorization: Bearer <accessToken>`
```json
{"recipientEmail":"ravi@example.com","amount":100.00}
```

### Transaction history
`GET http://localhost:8080/api/transactions`
Header: `Authorization: Bearer <accessToken>`

### Expected security behavior
- Public: `/api/auth/register`, `/api/auth/login`
- Protected: all other `/api/**` endpoints
- Missing/invalid/expired token: HTTP 401
- Insufficient funds or invalid transfer: HTTP 400
- Duplicate registration email: HTTP 409

## API summary

| Method | Endpoint | Purpose |
|---|---|---|
| POST | `/api/auth/register` | Create customer |
| POST | `/api/auth/login` | Authenticate and issue JWT |
| GET | `/api/account/balance` | Get logged-in customer's balance |
| POST | `/api/transfers` | Transfer funds to another registered customer |
| GET | `/api/transactions` | Show transactions involving logged-in customer |

## Notes
- Passwords are stored as BCrypt hashes.
- JWT is signed and verified using HS256-compatible HMAC key material.
- The server is stateless; clients send the bearer token on protected calls.
- Transfer updates and transaction logging run inside one database transaction, and customer rows are locked during the transfer.
- For a production system, use HTTPS, managed secrets/KMS, MFA, strict authorization, rate limiting, audit controls, idempotency, monitoring, and independent security review.
